# Rosacea vs Acne Classification

## Project Overview

This project is an AI image classification system developed to identify whether a skin image shows **Rosacea** or **Acne**. The application was built with TensorFlow/Keras and deployed using Streamlit.

## Features

- Upload a skin image.
- Predict Rosacea or Acne.
- Shows prediction confidence.
- Rejects unsupported images.

## Technologies Used

- Python
- TensorFlow/Keras
- Streamlit
- NumPy
- Pillow

## Project Structure

Rosacea_vs_Acne/
│── app.py
│── rosacea_vs_acne_model.keras
│── requirements.txt
│── README.md

## How to Run

Install dependencies:

pip install -r requirements.txt

Launch the application:

streamlit run app.py

Upload a skin image and view the prediction.

## Dataset

The model was trained using the MSC-6 Skin Condition Dataset from Kaggle, using only the Rosacea and Acne classes.

## Future Improvements

- Expand the dataset.
- Improve model accuracy.
- Add support for more skin conditions.
